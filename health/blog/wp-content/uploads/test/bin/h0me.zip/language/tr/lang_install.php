<?php
$lang['L_INSTALLFINISHED']="<br>Kurulum tamamlanmıştır   --> <a href=\"index.php\">MySQLDumper'i başlat </a><br>";
$lang['L_INSTALL_TOMENU']="Ana Menüye geç";
$lang['L_INSTALLMENU']="Ana Menüsü";
$lang['L_STEP']="Adım";
$lang['L_INSTALL']="Kurulum";
$lang['L_UNINSTALL']="Kurulumu kaldır";
$lang['L_TOOLS']="Araçlar";
$lang['L_EDITCONF']="Ayarları elden düzenle";
$lang['L_OSWEITER']="Kayıt etmeden devam et";
$lang['L_ERRORMAN']="Ayarların kaydında hata oluştu!</strong><br>Dosyayı lütfen elden düzenleyiniz ";
$lang['L_MANUELL']="elden";
$lang['L_CREATEDIRS']="Klasörler oluşturuluyor";
$lang['L_INSTALL_CONTINUE']="Kuruluma devam et";
$lang['L_CONNECTTOMYSQL']=" MySQL ile bağlan ";
$lang['L_DBPARAMETER']="Veritabanı-Parametreleri";
$lang['L_CONFIGNOTWRITABLE']="\"config.php\" yazılamıyor. FTP yazılımınız ile CHMOD ayarlarını 0777 ye çevirin.";
$lang['L_DBCONNECTION']="Bağlantı Parametreleri";
$lang['L_CONNECTIONERROR']="Hata: bağlantı kurulamıyor.";
$lang['L_CONNECTION_OK']="Veritabanı bağlantısı kuruldu.";
$lang['L_SAVEANDCONTINUE']="Kaydet ve kurulumu devam et";
$lang['L_CONFBASIC']="Asıl Ayarları";
$lang['L_INSTALL_STEP2FINISHED']="Veritabanı ayarları kayıt edildi.<br><br>
İsterseniz standart ayarlar ile kurulumu sürdürebilirsiniz, veya ayarları düzenleyebilirsiniz.";
$lang['L_INSTALL_STEP2_1']="Standart ayarlarla devam";
$lang['L_LASTSTEP']="Kurulumum tamamlanması";
$lang['L_FTPMODE']="Klasörler FTP ile oluşturuluyor (safe_mode)";
$lang['L_IDOMANUAL']="Klasörleri elden oluşturacağım";
$lang['L_DOFROM']="başlangıç:";
$lang['L_FTPMODE2']="klasörleri FTP ile oluştur";
$lang['L_CONNECT']="Bağlantı kur";
$lang['L_DIRS_CREATED']="Klasörler oluşturuldu.";
$lang['L_CONNECT_TO']="Bağlantı kur:";
$lang['L_CHANGEDIR']="Klasöre geç";
$lang['L_CHANGEDIRERROR']="Klasöre geciş mümkün değil";
$lang['L_FTP_OK']="FTP-Ayarları geçerli";
$lang['L_CREATEDIRS2']="Klasörleri oluştur";
$lang['L_FTP_NOTCONNECTED']="FTP-bağlantısı kurulmadı!";
$lang['L_CONNWITH']="Kurulacak bağlantı:";
$lang['L_ASUSER']="Kullanıcı";
$lang['L_NOTPOSSIBLE']="mümkün değil";
$lang['L_DIRCR1']="Oluşturuluyor: Çalışma klasörü";
$lang['L_DIRCR2']="Oluşturuluyor: yedekleme klasörü";
$lang['L_DIRCR4']="Oluşturuluyor: rapor klasörü";
$lang['L_DIRCR5']="Oluşturuluyor: ayar klasörü";
$lang['L_INDIR']="bulunulan klasör";
$lang['L_CHECK_DIRS']="Kontrol ediliyor";
$lang['L_DISABLEDFUNCTIONS']="İptal edilmiş fonksiyonlar";
$lang['L_NOFTPPOSSIBLE']="FTP fonksiyonları kullanılmaz!";
$lang['L_NOGZPOSSIBLE']="Sıkıştırma fonksiyonları kullanılmıyor!";
$lang['L_UI1']="Çalışma klasörleri siliniyor (içerisinde bulunan yedekleme dosyaları ile birlikte).";
$lang['L_UI2']="Eminmisiniz?";
$lang['L_UI3']="Hayır, hemen iptal et";
$lang['L_UI4']="Evet, eminim, devam et";
$lang['L_UI5']="Çalışma klasörü siliniyor";
$lang['L_UI6']="Hepsi silindi.";
$lang['L_UI7']="Skript klasörünü lütfen siliniz";
$lang['L_UI8']="Bir düzey yukarı çık";
$lang['L_UI9']="Hata oluştu, silme işlemi uygulanamadı</p>Hatanın oluştuğu klasör: ";
$lang['L_IMPORT']="Ayarları ithal et";
$lang['L_IMPORT3']="Ayarlar yüklendi...";
$lang['L_IMPORT4']="Ayarlar yedeklendi.";
$lang['L_IMPORT5']="MySQLDumper'i başlat";
$lang['L_IMPORT6']="Kurulum menüsü";
$lang['L_IMPORT7']="Ayarları yükle";
$lang['L_IMPORT8']="Yüklemeye geri dön";
$lang['L_IMPORT9']="Bu bir ayaryedeklemesi değil!";
$lang['L_IMPORT10']="Ayarlar yüklendi...";
$lang['L_IMPORT11']="<strong>Hata: </strong>SQL komutları yazarken hata oluştu";
$lang['L_IMPORT12']="<strong>Hata: </strong>Config.php nin kaydında hata oluştu";
$lang['L_INSTALL_HELP_PORT']="(boş = Standart port)";
$lang['L_INSTALL_HELP_SOCKET']="(boş= Standart socket)";
$lang['L_TRYAGAIN']="Bir daha dene";
$lang['L_SOCKET']="Socket";
$lang['L_PORT']="Port";
$lang['L_FOUND_DB']="Bulunan Veritabanı: ";
$lang['L_FM_FILEUPLOAD']="Dosya yükle";
$lang['L_PASS']="Şifre";
$lang['L_NO_DB_FOUND_INFO']="Veritabanı sunucusu ile bağlantı kuruldu.<br>
Bağlantı parametreleri doğrulandı, kullanıcı ismi ve şifresi kabul edildi.<br>
Fakat Sunucuda Veritabanı bulunamadı.<br>
Otomatik tanıma sunucunuzda kilitli olabilir.<br>
Kurulum tamamlandıktan sonra lütfen Ayar Merkezi sayfasına gidin ve Bağlantı parametreleri bölümünde \"göster\" tıklayınız.<br>
Veritabanı ile bağlantı kurulabilmesi için gereken bilgileri oraya girmeniz gerekiyor.";
$lang['L_SAFEMODEDESC']="Bu sunucudaki PHP ayarlarında \"safe_mode=on\" tespit edilmiştır, bazı klasörleri elden oluşturmanız gerekiyor (mesela FTP Client programı ile)";
$lang['L_ENTER_DB_INFO']="First click the button \"Connect to MySQL\". Only if no database could be detected you need to provide a database name here.";


?>