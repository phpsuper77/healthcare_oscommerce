<?php
$lang['L_LOG_DELETE']="xóa Log";
$lang['L_LOGFILEFORMAT']="Định dạng file nhật ký (logfile)";
$lang['L_LOGFILENOTWRITABLE']="Không thể ghi file nhật ký Logfile !";
$lang['L_NOREVERSE']="Cũ lên trên";
$lang['L_REVERSE']="Mới lên trên


";


?>