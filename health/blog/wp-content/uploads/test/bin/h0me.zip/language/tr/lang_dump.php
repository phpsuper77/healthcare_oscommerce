<?php
$lang['L_DUMP_HEADLINE']="yedekleme oluşturuluyor...";
$lang['L_GZIP_COMPRESSION']="GZip-sıkıştırma ";
$lang['L_SAVING_TABLE']="Tablo kaytediliyor ";
$lang['L_OF']="tarihinde";
$lang['L_ACTUAL_TABLE']="Geçerli tablo";
$lang['L_PROGRESS_TABLE']="Tablo işlem durumu";
$lang['L_PROGRESS_OVER_ALL']="Genel işlem durumu";
$lang['L_ENTRY']="Kayıt";
$lang['L_DONE']="Tamamlandı!";
$lang['L_DUMP_SUCCESSFUL']=" Başarıyla tamamlandı.";
$lang['L_UPTO']="kadar";
$lang['L_EMAIL_WAS_SEND']="Email başarıyla gönderildi. Alıcı:";
$lang['L_BACK_TO_CONTROL']="Devam";
$lang['L_BACK_TO_OVERVIEW']="Veritabanı listesi";
$lang['L_DUMP_FILENAME']="Yedeklenen dosyanın ismi: ";
$lang['L_WITHPRAEFIX']="Önekli";
$lang['L_DUMP_NOTABLES']="`<b>%s</b>` Veritabanında tablo bulunamadı.";
$lang['L_DUMP_ENDERGEBNIS']=" <b>%s</b> tabloda <b>%s</b> kayıt yedeklendi.<br>";
$lang['L_MAILERROR']="Mail gönderiminde hata oluştu!";
$lang['L_EMAILBODY_ATTACH']="Ekte veritabanıyın yedeklemesi bulunuyor.<br>yedeklenen Veritabanı `%s`
<br><br>Oluşturulan dosya:<br><br>%s <br><br>Sevgilerler<br><br>MySQLDumper<br><a href=\"http://www.mysqldumper.de/\">www.mysqldumper.de</a>";
$lang['L_EMAILBODY_MP_NOATTACH']="Çok parçalı yedekleme oluşturuldu.<br> Dosyalar eklenti olarak gönderilmiyor!<br>yedeklenen Veritabanı `%s`
<br><br>oluşturulan dosyalar:<br><br>%s<br><br><br>Sevgilerle<br><br>MySQLDumper<br><a href=\"http://www.mysqldumper.de/\">www.mysqldumper.de</a>";
$lang['L_EMAILBODY_MP_ATTACH']="Çok parçalı yedekleme oluşturuldu.<br>Dosyalar eklenti olarak gönderilmiyor!Dosyalar ayrı bir mail ile gönderiliyor!<br>Yedeklenen Veritabanı `%s`
<br><br>oluşturulan dosyalar:<br><br>%s<br><br><br>Sevgilerle<br><br>MySQLDumper<br><a href=\"http://www.mysqldumper.de/\">www.mysqldumper.de</a>";
$lang['L_EMAILBODY_FOOTER']="<br><br><br>Sevgiler<br><br>MySQLDumper<br><a href=\"http://www.mysqldumper.de/\">www.mysqldumper.de</a>";
$lang['L_EMAILBODY_TOOBIG']="Yedekleme boyutu maximumu boyut olan %s aştıgından dolayı eklenti olarak gönderilemiyor.<br>Yedeklenen Veritabanı `%s`
<br><br>oluşturulan dosyalar:<br><br>%s
<br><br>Saygılarla<br><br>MySQLDumper<br><a href=\"http://www.mysqldumper.de/\">www.mysqldumper.de</a>";
$lang['L_EMAILBODY_NOATTACH']="Yedekleme dosyaları maalesef eklenememiştir.<br>yedeklenen Veritabanı `%s`
<br><br>Oluşturulan Dosyalar:<br><br>%s
<br><br>Sevgilerle<br><br>MySQLDumper<br><a href=\"http://www.mysqldumper.de/\">www.mysqldumper.de</a>";
$lang['L_EMAIL_ONLY_ATTACHMENT']=" ... sadece eklentiler";
$lang['L_TABLESELECTION']="Tablo seçimi";
$lang['L_SELECTALL']="hepsini seç";
$lang['L_DESELECTALL']="hepsini kaldır";
$lang['L_STARTDUMP']="Yedeklemeyi başlat";
$lang['L_LASTBUFROM']="son yedekleme tarihi";
$lang['L_NOT_SUPPORTED']="Bu yedekleme istenilen fonksiyonu desteklemiyor.";
$lang['L_MULTIDUMP']="Parçalı yedekleme:<b>%d</b> Veritabanları yedeklendi.";
$lang['L_FILESENDFTP']="Dosya FTP ile gönderiliyor... lütfen biraz bekleyiniz. ";
$lang['L_FTPCONNERROR']="FTP-Bağlantısı kurulmadı! Bağlantı  ";
$lang['L_FTPCONNERROR1']=" Kullanıcı";
$lang['L_FTPCONNERROR2']=" mümkün değil";
$lang['L_FTPCONNERROR3']="FTP-Yüklemesi başarısız! ";
$lang['L_FTPCONNECTED1']="Kullanılan bağlantı";
$lang['L_FTPCONNECTED2']=" ile ";
$lang['L_FTPCONNECTED3']=" kayıt edilen";
$lang['L_NR_TABLES_SELECTED']="-  %s seçilmiş tablolar";
$lang['L_NR_TABLES_OPTIMIZED']="<span class=\"small\">%s Tablo arındırıldı.</span>";
$lang['L_DUMP_ERRORS']="<p class=\"error\">Hata %s oluştu: <a href=\"log.php?r=3\">göster</a></p>";
$lang['L_FATAL_ERROR_DUMP']="Hata oluştu: CREATE komutu '%s'tablosu '%s' veritabanında okunamadı<br>Tabloları onarmanızı öneriyoruz.";


?>